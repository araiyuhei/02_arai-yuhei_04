<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php


$a= mt_rand(1, 3);

if ($a==1) {
        echo "ぐー";
        echo '<img src="fortune/26334454.jpg" style="width:200px;height:200px">';
 }
 
 if($a==2){
        echo "ちょき";
        echo '<img src="fortune/26334455.png" style="width:200px;height:200px">';
 }
 if($a==3){
        echo "ぱー";
        echo '<img src="fortune/26334456.jpg" style="width:200px;height:200px">';
}













?>
</body>
</html>